using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;

public class pm2 : MonoBehaviour
{
    //Khai báo biến nhân vật
    public Rigidbody2D rb; //private Rigidbody2D rb;

    //Khai báo biến tham số
    //Tốc độ di chuyển
    public float moveSpeed;
    //Tốc độ nhảy
    public float jumpSpeed;
    public bool nhay;
    public Animator animator;
    public Transform playerY;
    public GameObject Panel, panelesc;
    public GameObject Text, textEsc;
    public GameObject Btn, HomeEsc, Btnesc;
    public GameObject choiTiep;
    public GameObject player;
    public GameObject Home;
    public TextMeshProUGUI diemText;
    public TextMeshProUGUI Score;
    public int highScore; // luu so diem trong qua trinh choi
    public int currenScore;
    // Điểm rơi của nhân vật
    public Transform respawnPoint;
    public bool isDead;
    void Start()
    {
        //Gán giá trị mặc định ban đầu cho tốc độ di chuyển, nhảy
        moveSpeed = 10f;
        jumpSpeed = 6.5f;
        animator = GetComponent<Animator>();
        currenScore = 0;

        // lay diem high score
        highScore = PlayerPrefs.GetInt("HighScore");
        Score.text = "Score " + highScore.ToString("n0");
    }

    void Update()
    {
        //Nếu phím 
        if (Input.GetKeyDown(KeyCode.Space) && nhay) playerJump(jumpSpeed);
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            panelesc.SetActive(true);
            textEsc.SetActive(true);
            HomeEsc.SetActive(true);
            Btnesc.SetActive(true);
            Time.timeScale = 0;
        }
    }

    private void FixedUpdate()
    {
        playerRun(moveSpeed);
    }

    void playerJump(float jumpSpeed)
    {
        rb.velocity = new Vector2(rb.velocity.x, jumpSpeed);
    }

    void playerRun(float moveSpeed)
    {
        rb.velocity = new Vector2(moveSpeed, rb.velocity.y);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "nendat")
        {
            nhay = true;
            animator.SetBool("nhya", false);
        }
        if (other.gameObject.tag == "vang")
        {

            currenScore++;
            diemText.text = " " + currenScore.ToString("n0");

        }
        else if (other.gameObject.tag == "roixuong")
        {
            Time.timeScale = 0f;
            Home.SetActive(true);
            Panel.SetActive(true);
            Text.SetActive(true);
            Btn.SetActive(true);
            // float playerX = player.transform.position.x;
            // SetObjectXPosition(Panel, playerX);
            // SetObjectXPosition(Home, playerX);
            // SetObjectXPosition(Btn, playerX);
            // SetObjectXPosition(Text, playerX);
            if (currenScore > highScore)
            {
                highScore = currenScore;
                PlayerPrefs.SetInt("HighScore", highScore);

            }
        }
        if (other.gameObject.tag == "quai")
        {
            Time.timeScale = 0;
            Panel.SetActive(true);
            Home.SetActive(true);
            Text.SetActive(true);
            Btn.SetActive(true);
            // float playerX = player.transform.position.x;
            // SetObjectXPosition(Panel, playerX);
            // SetObjectXPosition(Home, playerX);
            // SetObjectXPosition(Btn, playerX);
            // SetObjectXPosition(Text, playerX);
            if (currenScore > highScore)
            {
                highScore = currenScore;
                PlayerPrefs.SetInt("HighScore", highScore);

            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.tag == "nendat")
        {
            nhay = false;
            animator.SetBool("nhya", true);
        }
    }
    // void SetObjectXPosition(GameObject obj, float xPosition)
    // {
    //     if (obj != null)
    //     {
    //         Vector3 newPosition = obj.transform.position;
    //         newPosition.x = xPosition;
    //         obj.transform.position = newPosition;
    //     }
    //     else
    //     {
    //         Debug.LogError("GameObject không được gán hoặc là null.");
    //     }
    // }
}
